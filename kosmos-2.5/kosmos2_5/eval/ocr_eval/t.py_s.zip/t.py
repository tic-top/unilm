import os
import json

def process_json(json_data):
    result_lines = []
    for item in json_data['results']:
        text = item['text']
        bbox = item['bounding box']
        x0, y0, x1, y1 = bbox['x0'], bbox['y0'], bbox['x1'], bbox['y1']
        line = f"{x0},{y0},{x1},{y0},{x1},{y1},{x0},{y1},{text}"
        result_lines.append(line)
    return result_lines

def process_files(input_dir):
    for folder_name in os.listdir(input_dir):
        folder_path = os.path.join(input_dir, folder_name)
        if os.path.isdir(folder_path):
            for file_name in os.listdir(folder_path):
                if file_name.endswith('.json'):
                    file_path = os.path.join(folder_path, file_name)
                    with open(file_path, 'r') as json_file:
                        json_data = json.load(json_file)
                        result_lines = process_json(json_data)
                        
                    # Write to txt file with the same name
                    txt_file_path = file_path.replace('.json', '.txt')
                    with open(txt_file_path, 'w') as txt_file:
                        for line in result_lines:
                            txt_file.write(line + '\n')
                    
                    # Remove the original json file
                    os.remove(file_path)

input_directory = '.'  # Current directory
process_files(input_directory)
